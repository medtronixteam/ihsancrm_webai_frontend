let data = ` <div id="form_modal" class="form-modal" style="display: none;">
    <div class="content">
        <div class="top-content">
            <div>
                <img src="http://app.ihsancrm.com/public/web/chat-image.svg" alt="not-Show" />
            </div>
            <div class="ihsan-header" style="padding-left: 20px;">
                <h2>IHSAN AI</h2>
                <p>Our Bots Answers Instantly</p>
            </div>
        </div>
        <div>
            <form  id="ihsanCRMWebAiForm" class="chat_form" method="post">
                <label for="name">Name</label>
                <input id="nameOfUser" name="name" type="text" placeholder="Enter Your Name" required />
                <label for="email">Email</label>
                <input id="nameOfEmail" name="email" type="email" placeholder="Enter Your Email" required />
                <button type="submit">Submit</button>
            </form>
        </div>

       
 <a href="#"  class="closeModalBtn"><i class="fa fa-times fa-1x" aria-hidden="true"></i></a>
    </div>
</div>
<!-- ihsanAi-modal -->

`;



function ihsanCRM(nameDiv, obj) {

    sessionStorage.setItem('AUTHTOKENIH', obj.token);

    if (document.getElementById(nameDiv)) {
        console.log('Bot is initialized')
        let dT = `<a class="formModal_btn"><img src="http://app.ihsancrm.com/public/web/message-logo.svg" alt="" style="width: 35px;"></a>`;
        let flag = 0;
        if (flag == 0) {
            document.getElementById(nameDiv).innerHTML = dT + data;
        } else {


        }
        // Form Modal show data⭐






        // Add a click event listener to the formModalBtn link
        //if (document.querySelector(".formModal_btn")) {


        document.querySelector(".formModal_btn").addEventListener("click", function(event) {
            var formModalDiv = document.getElementById("form_modal");
            event.preventDefault(); // Prevent the link from navigating

            // Toggle the visibility of the form_modal div
            if (formModalDiv.style.display === "none") {
                formModalDiv.style.display = "block";
            } else {
                formModalDiv.style.display = "none";
            }
        });
        //}
        // chat Modal  show data⭐
        var chatModalDiv = document.getElementById("chat_modal");
        var formModalBtn = document.querySelector(".formModal_btn");

        // Add a click event listener to the formModalBtn link
        if (formModalBtn) {
            formModalBtn.addEventListener("click", function(event) {

                event.preventDefault(); // Prevent the link from navigating

                // Toggle the visibility of the chat_modal div
                if (chatModalDiv.style.display === "none") {
                    chatModalDiv.style.display = "block";
                } else {
                    chatModalDiv.style.display = "none";
                }
            });
        }
        // colse Form_Modal ⭐

        document.addEventListener("DOMContentLoaded", function() {



            // Add a click event listener to the close link
            document.querySelector(".closeModalBtn").addEventListener("click", function(event) {
                var chatModalDiv = document.getElementById("chat_modal");

                event.preventDefault();

                closeTabsofModal();

            });
        });
        if (document.getElementById("ihsanCRMWebAiForm")) {
            document.getElementById("ihsanCRMWebAiForm").addEventListener("submit", function(e) {
                e.preventDefault(); // Prevent the default form submission
                // Get form data
                const name = document.getElementById("nameOfUser").value;
                const email = document.getElementById("nameOfEmail").value;
                if (sessionStorage.getItem("AUTHTOKENIH")) {
                    // Variable is initialized

                    // Create a data object with the form data
                    const formData = {
                        name: name,
                        email: email,
                        token: sessionStorage.getItem("AUTHTOKENIH"),
                    };

                    // Convert the data object to JSON
                    const jsonData = JSON.stringify(formData);

                    // Make a POST request to your API
                    fetch("http://app.ihsancrm.com/api/web/instance", {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json",
                            },
                            body: jsonData,
                        })
                        .then((response) => response.json())
                        .then((data) => {
                            // let responseData = JSON.parse(data);
                            console.log(data.status);

                            if (data.status == 200) {

                                let chatMsg = getCHATBrows(data.name, data.message);
                                document.getElementById("form_modal").style.display = 'none';
                                document.getElementById(nameDiv).innerHTML = dT + chatMsg;

                            }
                        })
                        .catch((error) => {
                            console.error("Error:", error);
                        });
                }
            });
        }

    } else {

        console.log("The div does not exist.");
    }
}

function getCHATBrows(name, question) {
    return (`<div id="chat_modal" class="ihsanAi-modal" >
<div class="content">
    <div class="top-content">
        <div>
            <img src="http://app.ihsancrm.com/public/web/chat-image.svg" alt="not-Show"/>
        </div>
        <div style="padding-left: 20px;">
            <h2>` + name + `</h2>
            <p>Powered By <span>IHSAN AI</span></p>
        </div>
    </div>
    <div style="height: 360px; background-color: rgb(245, 245, 249); margin: 0px 26px;">
        <div class="chat-content scrollbar">
            <div class="left-div">
                <div class="chat-bubble">
                    <p>` + question + `
                       
                    </p>
                </div>
            </div>
        
        </div>
    </div>
    <div style="background-color:white;">
        <form action="">
            <div style="display: flex; justify-content: center; padding: 10px 0px;">
                <textarea class="type_message scrollbar" name=""
                    placeholder="Type your message here..."></textarea>
                <button class="send-message" type="submit"><img src="http://app.ihsancrm.com/public/web/send-msg.svg" alt=""></button>
            </div>
        </form>
    </div>

    <a href="javascript:void(0)"  class="closeModalBtn"><i class="fa fa-times fa-1x" aria-hidden="true"></i></a>
</div>
</div>`);

}

function closeTabsofModal() {

    if (document.querySelector(".ihsanAi-modal")) {
        document.querySelector(".ihsanAi-modal").style.display = "none";
    }
    if (document.getElementById("form_modal")) {
        document.getElementById("form_modal").style.display = "none";
    }

}
